import java.util.*;
import static java.lang.System.*;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(in);
        MonthlyReport monthlyReport = null;
        YearlyReport yearlyReport = null;
        ArrayList<MonthlyReport> month = new ArrayList<>();
        NameMonth nameMonth;
            while (true) {
            printMenu();
            int command = scanner.nextInt();
            if (command == 1) {
                if (monthlyReport == null) {
                    for (int i = 1; i <= 3; i++) {
                        String nameFile = "m.20210" + i + ".csv";
                        monthlyReport = new MonthlyReport("resources/" + nameFile);
                        month.add(monthlyReport);
                    }
                } else {
                    System.out.println("Все месячные отчеты уже считаны");
                }
            } else if (command == 2) {
                if (yearlyReport == null) {
                    yearlyReport = new YearlyReport("resources/y.2021.csv");

                } else {
                    System.out.println("Годовой отчет уже считан");
                }
            } else if (command == 3) {
                    Checker checker = new Checker(monthlyReport, yearlyReport);
                    nameMonth = new NameMonth(yearlyReport);
                        for (MonthlyReport report : month) {        // для каждого файла месяца
                            System.out.println(nameMonth.nameMonth().get(month.indexOf(report)) + " месяц. Доход: " + checker.sumMonth(report).get(false));
                            System.out.println(nameMonth.nameMonth().get(month.indexOf(report)) + " месяц. Расход: " + checker.sumMonth(report).get(true));
                        }
                for (MonthlyReport report : month) {
                    String index = nameMonth.nameMonth().get(month.indexOf(report));
                    System.out.println(checker.check(report, index));
                    if (!checker.check(report, index)) {
                        System.out.println("В " + index + " месяце данные не совпадают с данными в отчете за " + yearlyReport.nameYear());
                    } else System.out.println("В " + index + " месяце данные совпадают с данными в отчете за " + yearlyReport.nameYear());
                }
            } else if (command == 4) {
                nameMonth = new NameMonth(yearlyReport);
                for (int i = 0; i <= 2; i++) {
                    System.out.println(nameMonth.nameMonth().get(i) + " месяц:");
                    System.out.println("Самый прибыльный товар: " + month.get(i).topNameProfit());
                    System.out.println("Общая сумма: " + month.get(i).maxSum(month.get(i).topNameProfit()));
                    System.out.println("Самая большая трата : " + month.get(i).topNameSpend());
                    System.out.println("Общая сумма: " + month.get(i).maxSum(month.get(i).topNameSpend()));
                }
            } else if (command == 5) {
                nameMonth = new NameMonth(yearlyReport);
                System.out.println(yearlyReport.nameYear() + " год");
                for (int i = 0; i < nameMonth.nameMonth().size(); i++) {
                    System.out.println("Прибыль за " + nameMonth.nameMonth().get(i) + " месяц: " + yearlyReport.difference(nameMonth.nameMonth().get(i)));
                }
                System.out.println("Средний расход за все месяцы в году: " + yearlyReport.averagePlus());
                System.out.println("Средний доход за все месяцы в году: " + yearlyReport.averageMinus());
            } else if (command == 6) {
                System.out.println("Для выхода из программы введите: exit");
                String exit = scanner.next();
                if (exit.equals("exit")) {
                    break;
                } else {
                    System.out.println("Такой команды нет. Выход в основное меню");
                }
            } else {
                System.out.println("Такой команды нет. Пожалуйста, повторите запрос");
            }
        }
    }
    private static void printMenu() {
        System.out.println("1. Считать все месячные отчёты");
        System.out.println("2. Считать годовой отчёт");
        System.out.println("3. Сверить отчёты");
        System.out.println("4. Вывести информацию о всех месячных отчётах");
        System.out.println("5. Вывести информацию о годовом отчёте");
        System.out.println("6  Выйти из программы");
    }
}