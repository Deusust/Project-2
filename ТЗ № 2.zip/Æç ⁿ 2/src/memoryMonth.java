public class memoryMonth {
    public String name;
    public boolean isExpense;
    public int quantity;
    public int sumOfOne;
    public memoryMonth(String name, boolean isExpense, int quantity, int sumOfOne) {
        this.name = name;
        this.isExpense = isExpense;
        this.quantity = quantity;
        this.sumOfOne = sumOfOne;
    }
}