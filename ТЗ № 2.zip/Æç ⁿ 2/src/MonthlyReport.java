import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
public class MonthlyReport {
    ArrayList<memoryMonth> memories = new ArrayList<>();
    HashMap<String, Integer> freqs = new HashMap<>();
    public MonthlyReport(String path) {
        String line = readFileContents(path);
        String[] lineContents = line.split("\n");
        for (int i = 1; i < lineContents.length; i++) {
            String thisLine = lineContents[i];
            String[] parts = thisLine.split(",");
            String name = parts[0];
            boolean isExpense = Boolean.parseBoolean(parts[1]);
            int quantity = Integer.parseInt(parts[2]);
            int sumOfOne = Integer.parseInt(parts[3]);
            memoryMonth memoryMonth = new memoryMonth(name, isExpense, quantity, sumOfOne);
            memories.add(memoryMonth);
        }
    }
    public String topNameProfit() {         // имя лучшей прибыли
        freqs.clear();
        String maxName;
        for (memoryMonth memory : memories) {
            if (!memory.isExpense) {
                freqs.put(memory.name, memory.quantity * memory.sumOfOne);
            }
        }
        maxName = getName();
        return maxName;
    }
    public String topNameSpend() {          // имя лучшей траты
        freqs.clear();
        String maxName;
        for (memoryMonth memory : memories) {
            if (memory.isExpense) {
                freqs.put(memory.name, memory.quantity * memory.sumOfOne);
            }
        }
        maxName = getName();
        return maxName;
    }
    public String getName() {                           // получить имя максимальной траты или прибыли
        String maxName = null;
        for (String name : freqs.keySet()) {
            if (maxName == null) {
                maxName = name;
                continue;
            }
            if (freqs.get(maxName) < freqs.get(name)) {
                maxName = name;
            }
        }
        return maxName;
    }
    public int maxSum(String maxName) {         // получить максимальную сумму
        return freqs.get(maxName);
    }
    static String readFileContents(String path) {
        try {
            return Files.readString(Path.of(path));
        } catch (IOException e) {
            System.out.println("Невозможно прочитать файл с месячным отчётом. Возможно файл не находится в нужной директории.");
            return null;
        }
    }
}