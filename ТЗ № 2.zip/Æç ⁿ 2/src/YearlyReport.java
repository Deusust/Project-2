import java.util.ArrayList;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
public class YearlyReport {
    ArrayList<memoryYear> memories = new ArrayList<>();
    public YearlyReport(String path) {
        String line = readFileContents(path);
        String[] lineContents = line.split("\n");
        for (int i = 1; i < lineContents.length; i++) {
            String thisLine = lineContents[i];
            String[] parts = thisLine.split(",");
            String month = parts[0];
            int amount = Integer.parseInt(parts[1]);
            boolean isExpense = Boolean.parseBoolean(parts[2]);
            memoryYear memoryYear = new memoryYear(month, amount, isExpense);
            memories.add(memoryYear);
        }
    }
    public String nameYear() {
        return "2021";
    }
    public int difference(String month) {           // прибыль по каждому месяцу
        int difference;
        int amountPlus = 0;
        int amountMinus = 0;
        for (memoryYear memory : memories) {
            if ((memory.month.equals(month)) && (!memory.isExpense)) {
                amountPlus = memory.amount;
            } else if (memory.month.equals(month)) {
                amountMinus = memory.amount;
            }
        }
        difference = amountPlus - amountMinus;
        return difference;
    }
    public int averagePlus() {          //средний доход за все месяцы
        int sum = 0;
        int average;
        int step = 0;
        for (memoryYear memory : memories) {
            if (!memory.isExpense) {
                sum += memory.amount;
                step += 1;
            }
        }
        average = sum / step;
        return average;
    }
    public int averageMinus() {         // средний расход за все месяцы
        int sum = 0;
        int average;
        int step = 0;
        for (memoryYear memory : memories) {
            if (memory.isExpense) {
                sum += memory.amount;
                step += 1;
            }
        }
        average = sum / step;
        return average;
    }
    static String readFileContents(String path) {
        try {
            return Files.readString(Path.of(path));
        } catch (IOException e) {
            System.out.println("Невозможно прочитать файл с месячным отчётом. Возможно файл не находится в нужной директории.");
            return null;
        }
    }
}