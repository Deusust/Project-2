import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Set;
public class NameMonth {
    YearlyReport yearlyReport;
    public NameMonth (YearlyReport yearlyReport) {
        this.yearlyReport = yearlyReport;
    }
    public ArrayList<String> nameMonth() {      //метод возвращает список из наименований месяцев
        ArrayList<String> nameMonth = new ArrayList<>();
        for (memoryYear memory : yearlyReport.memories) {
            nameMonth.add(memory.month);
        }
        Set<String> setNameMonth = new LinkedHashSet<>(nameMonth);
        ArrayList<String> arrayNameMonth = new ArrayList<>(setNameMonth);
        return arrayNameMonth;       //{01, 02, 03}
    }
}
