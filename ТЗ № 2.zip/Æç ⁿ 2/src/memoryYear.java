public class memoryYear {
    public String month;
    public int amount;
    public boolean isExpense;
    public memoryYear(String month, int amount, boolean isExpense) {
        this.month = month;
        this.amount = amount;
        this.isExpense = isExpense;
    }
}