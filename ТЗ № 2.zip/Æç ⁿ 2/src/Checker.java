import java.util.HashMap;
import java.util.Objects;
public class Checker {
    public MonthlyReport monthlyReport;
    public YearlyReport yearlyReport;
    public NameMonth nameMonth;
    public Checker(MonthlyReport monthlyReport, YearlyReport yearlyReport) {
        this.monthlyReport = monthlyReport;
        this.yearlyReport = yearlyReport;
        this.nameMonth = new NameMonth(yearlyReport);
    }
    public HashMap<Boolean, Integer> sumMonth(MonthlyReport monthlyReport) {      // метод возвращает мапу с доходами и расходами по одному месяцу
        HashMap<Boolean, Integer> sumMonth = new HashMap<>();   // мапа с доходами и расходами за месяц, ключ - доход, расход; значение - общая сумма доходов, расходов
        int sumIncMonth = 0;
        int sumExpMonth = 0;
        for (memoryMonth memory : monthlyReport.memories) {         // по всем строкам файла одного месяца
            if (!memory.isExpense) {
                sumIncMonth += memory.quantity * memory.sumOfOne;
            } else {
                sumExpMonth += memory.quantity * memory.sumOfOne;
            }
            sumMonth.put(false, sumIncMonth);
            sumMonth.put(true, sumExpMonth);
        }
        return sumMonth;    // {false, int} {true, int}
    }
    public HashMap<String, HashMap<Boolean, Integer>> sumExpYear () {      //мапа годовая с расходами: {01, 02, 03} => {true, sum}, {true, sum}, {true, sum}
        HashMap<String, HashMap<Boolean, Integer>> sumExpYear = new HashMap<>();
        for (memoryYear memory : yearlyReport.memories) {
            if (memory.isExpense == true) {
                HashMap<Boolean, Integer> sum = new HashMap<>();
                sum.put(memory.isExpense, memory.amount);
                sumExpYear.put(memory.month, sum);
            }
        }
        return sumExpYear;  // {01, 02, 03} {true, int}
    }
    public HashMap<String, HashMap<Boolean, Integer>> sumIncYear () {      //мапа годовая с доходами:  {01, 02, 03} => {false, sum}, {false, sum}, {false, sum}
        HashMap<String, HashMap<Boolean, Integer>> sumExpYear = new HashMap<>();
        for (memoryYear memory : yearlyReport.memories) {
            if (memory.isExpense == false) {
                HashMap<Boolean, Integer> sum = new HashMap<>();
                sum.put(memory.isExpense, memory.amount);
                sumExpYear.put(memory.month, sum);
            }
        }
        return sumExpYear;  // {01, 02, 03} {false, int}
    }
    public boolean check (MonthlyReport monthlyReport, String index) {
        boolean check;
        HashMap<Boolean, Integer> resultInc;
        HashMap<Boolean, Integer> resultExp;
        resultInc = sumIncYear().get(index);    // {false, int} => index = 01, 02, 03
        resultExp = sumExpYear().get(index);    // {true, int}  => index = 01, 02, 03
        if ((!Objects.equals(sumMonth(monthlyReport).get(false), resultInc.get(false))) || (!Objects.equals(sumMonth(monthlyReport).get(true), resultExp.get(true)))) {
            check = false;
        } else check = true;
        return check;
    }
}